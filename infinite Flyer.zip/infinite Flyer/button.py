import pygame

class Button:
    def __init__(self,x,y,scale):
        image1 = pygame.image.load("assets/blue_button00.png").convert_alpha()
        self.width = image1.get_width()
        self.height = image1.get_height()
        self.image1 = pygame.transform.scale(image1,(int(self.width*scale),int(self.height*scale)))
        image2 = pygame.image.load("assets/blue_button01.png").convert_alpha()
        self.image2 = pygame.transform.scale(image2,(int(self.width*scale),int(self.height*scale)))
        image3 = pygame.image.load("assets/blue_button01.png").convert_alpha()
        self.image3 = pygame.transform.scale(image2,(int(self.width*scale),int(self.height*scale)))
        self.x = x - self.image1.get_width()/2
        self.y = y - self.image1.get_height()/2
        self.rect = self.image1.get_rect()
        self.rect.topleft = (self.x, self.y)
        self.image = self.image1
        self.clicked = False

        
    def draw(self,surface):
        #self.clicked = False
        #pos = pygame.mouse.get_pos()
        #if self.rect.collidepoint(pos):
        #    if pygame.mouse.get_pressed()[0] and (not self.clicked):
        #        self.clicked = True
        #        self.image = self.image2
        #        print ("clicked")            
        #else:
        #    self.image = self.image1
        surface.blit(self.image,(self.rect.x,self.rect.y))
        #return self.clicked

    def is_clicked(self):
        pos = pygame.mouse.get_pos()
        if self.rect.collidepoint(pos):
            #self.clicked = True
            self.image = self.image2 and self.image3
            return True

        return False    
            
        
    
