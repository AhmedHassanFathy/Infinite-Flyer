# In a separate file (you can call that file "homework.py") create variable and make it equals to these values: [53,4,37,26,10]
# Use the for loop and the "range" keyword to print out all the values inside the list we created.

backpack_list = [53,4,37,26,10]        #list
for item in backpack_list:             #for loop(enumerates through list)
    print (item)
count = 0 
while count < 10:
    print ("hello")
    count += 1




class test:
    def __init__(self):
        self.x = 5
        self.y = 10
        self.r = "hello"

test1 = test()
test2 = test()

test1.r = 20
print(test2.r)