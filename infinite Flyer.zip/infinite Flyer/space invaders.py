import pygame
import random
from button import Button


#start game
pygame.init()
WIDTH = 1000
HEIGHT = 500
screen = pygame.display.set_mode((WIDTH,HEIGHT))
Clock = pygame.time.Clock()
font = pygame.font.Font('freesansbold.ttf', 32)

#score
def show_score(x, y):
    score = font.render("score :" + str(score_value), True, (255,255,255))
    screen.blit(score, (x, y))
        
        
#music
#pygame.mixer.music.load("/Users/ahmedhassan/Desktop/CodaKid/Ahmed's project/assets/background.wav")
#pygame.mixer.music.play(-1)
#pygame.mixer.music.set_volume(0.2)

#alien
class alien:
    def __init__(self,x,y):
        self.x=x
        self.y=y
        self.image = pygame.image.load("/Users/ahmedhassan/Desktop/CodaKid/Ahmed's project/assets/alien.png")
        self.width = self.image.get_width()
        self.height = self.image.get_height()
        self.hitbox = pygame.Rect(self.x, self.y, self.width, self.height)
        self.speed = 0.3
        self.direction = 1
        self.distance = 0
        self.shoot_timer_max = 30
        self.shoot_timer = self.shoot_timer_max
        
    def update(self):
        global score_value
        self.shoot_timer -= 1
        if self.shoot_timer <= 0:
            if random.randint(0,30) == 1:
               alien_rockets.append(Rocket (self.x + self.width, self.y,3,-1)) 
            self.shoot_timer = self.shoot_timer_max
        self.x += self.speed *self.direction
        self.distance += self.speed
        if self.distance > self.width *2:
            self.direction *= -1
            self.distance = 0
            self.y += self.height
        self.hitbox = pygame.Rect(self.x, self.y, self.width, self.height)
        screen.blit(self.image,(self.x,self.y))
        for rocket in rockets:
            if self.hitbox.colliderect(rocket.hitbox):
                rockets.remove(rocket)
                aliens.remove(self)
                score_value += 10
                self.hitbox.y = self.y
                self.hitbox.x = self.x
        if self.y > 450:
            return False
        else:
            return True

#rocket
class Rocket:
    def __init__(self,x,y,speed,direction):
        if direction > 0:
            self.image = pygame.image.load("/Users/ahmedhassan/Desktop/CodaKid/Ahmed's project/assets/laser.png")
        else:
            self.image = pygame.image.load("/Users/ahmedhassan/Desktop/CodaKid/Ahmed's project/assets/alien_laser.png")
        self.x=x
        self.y=y
        self.speed = speed
        self.direction = direction
        self.width = self.image.get_width()
        self.height = self.image.get_height()
        self.hitbox = pygame.Rect(self.x, self.y, self.width, self.height)
    def update(self):
        self.y -= self.speed*self.direction
        self.hitbox.y = self.y
        pygame.draw.rect(screen, (0, 0, 0), self.hitbox)
        screen.blit(self.image,(self.x,self.y))

global score_value

#variables
running = True
player_image = pygame.image.load("assets/player_01.png")
player_width = player_image.get_width()
player_shoot_timer_max = 40
player_shoot_timer = 0
player_height = player_image.get_height()
player_x = WIDTH/2 - player_width/2
background = pygame.image.load("assets/back.png")
y_margin = 60
x_margin = int(WIDTH/8)
player_y = HEIGHT - player_height
player_hitbox = pygame.Rect(player_x, player_y, player_width, player_height)
score_value = 0
player_alive = True
defeat = pygame.image.load("assets/defeat.png")
victory = pygame.image.load("assets/victory.png")
#array
aliens = []
rockets = []
alien_rockets = []
is_menu = True
button = Button(500,250,2)

for x in range(0,7):
    for y in range(0,5):
        aliens.append(alien(x*x_margin,y*y_margin))

screen.blit(background,(0,0))      

#while loop
while running:
    Clock.tick(50)
    screen.fill((0,0,0))
    if is_menu:
        if button.draw(screen):
            print("Clicked")
            is_menu = False 
    if not is_menu: 
        show_score(10, 10) 
        if player_alive:
            for rocket in alien_rockets:
                rocket.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                running = False
        if player_alive:
            screen.blit(player_image,(player_x,450))
        screen.blit(background,(0,0))
        for alien in aliens:
            if player_alive == True:
                player_alive = alien.update()
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            player_x -= 3
        if keys[pygame.K_RIGHT]:
            player_x += 3
        if keys[pygame.K_SPACE] and player_shoot_timer < 1 and player_alive == True:
            rockets.append(Rocket(player_x + 20,440,6,1))
            player_shoot_timer = 50
        for rocket in rockets:
            rocket.update()
        if player_shoot_timer > 0:
            player_shoot_timer -= 1
        if player_alive:
            player_hitbox.x = player_x
        for alien_rocket in alien_rockets:
            if player_hitbox.colliderect(alien_rocket.hitbox):
                player_alive = False
            if player_alive == False:
               screen.fill('black')
               screen.blit(defeat, (400, 250))
        if len(aliens) == 0:
            screen.blit(victory, (400,250))
    pygame.display.flip()           
            
            
                

