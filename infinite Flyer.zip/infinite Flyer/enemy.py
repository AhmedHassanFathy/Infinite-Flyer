import pygame
import random

class enemy:
    def __init__(self, x, screen):
        self.spr_enemy = pygame.image.load("assets/alien.png")
        self.spr_enemy = pygame.transform.rotate(self.spr_enemy, 270)
        self.x = x
        self.y = random.randint(0, screen.get_height() - self.spr_enemy.get_height())
        self.screen = screen
        self.speed = random.randint(3, 11)

    def move(self):
        self.x -= self.speed
        if self.x < 0:
            self.x = self.screen.get_width()
            self.y = random.randint(0, self.screen.get_height() - self.spr_enemy.get_height())
            self.speed = random.randint(3, 11)

    def draw(self):
        self.screen.blit(self.spr_enemy, (self.x, self.y))
        
        
