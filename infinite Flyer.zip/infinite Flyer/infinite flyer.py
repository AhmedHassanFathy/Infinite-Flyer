from enemy import *
from button import *
import utils

pygame.init()
# create screen
SIZE = (800, 600)
BLACK = (0, 0, 0)
screen = pygame.display.set_mode(SIZE)
bg = pygame.image.load("assets/back.png")
bg = pygame.transform.scale(bg, (screen.get_width(), screen.get_height()))
font = pygame.font.Font('freesansbold.ttf', 32)
score = 0
current_level = 1
pygame.mixer.music.load("assets/Flight_Music.wav")
# create rectangle
button = Button(screen.get_width() / 2, screen.get_height() / 2, 2)

spr_player = pygame.image.load("assets/player_01.png")
spr_player = pygame.transform.rotate(spr_player, 270)

spr_missile = pygame.image.load("assets/missile.png")
missile_speed = 7
all_missiles = []

alien_0 = enemy(750, screen)
alien_1 = enemy(750, screen)
alien_2 = enemy(750, screen)
alien_3 = enemy(750, screen)
all_aliens = [alien_0, alien_1, alien_2, alien_3]
aliens_on_screen = []

for alien_enemy in all_aliens:
    aliens_on_screen.append(alien_enemy)

player = {
    'x': 0,
    'y': 0,
    'width': spr_player.get_width(),
    'height': spr_player.get_height()
}

running = True
Clock = pygame.time.Clock()
is_menu = True
number_clicked = 0
is_music = False
while running:
    Clock.tick(25)
    keys = pygame.key.get_pressed()
    pygame_events = pygame.event.get()

    for event in pygame_events:
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.MOUSEBUTTONUP:
            if button.is_clicked():
                number_clicked += 1

    screen.blit(bg, (0, 0))

    if is_menu:
        button.draw(screen)

        if number_clicked >= 2:
            is_menu = False

    elif not is_menu:
        if not is_music :
            pygame.mixer.music.play(-1)
            pygame.mixer.music.set_volume(0.5)
            is_music = True
        if keys[pygame.K_w] and player['y'] > 0:
            player['y'] -= 3

        elif keys[pygame.K_s] and player['y'] < (SIZE[1] - player['height']):
            player['y'] += 3

        if keys[pygame.K_d] and player['x'] < 300:
            player['x'] += 3

        elif keys[pygame.K_a] and player['x'] > 0:
            player['x'] -= 3

        for event in pygame_events:
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_SPACE:
                    m1 = {
                        "x": player['x'],
                        "y": player['y']
                    }
                    all_missiles.append(m1)
                    m2 = {
                        "x": player['x'],
                        "y": player['y'] + player['height']
                    }
                    all_missiles.append(m2)

        screen.blit(bg, (0, 0))
        screen.blit(spr_player, (player['x'], player['y']))

        for alien in aliens_on_screen:
            alien.draw()

        aliens_to_remove = set()  # Changes here
        missile_to_destroy = []  # Changes here

        for missile in all_missiles:
            screen.blit(spr_missile, (missile["x"], missile["y"]))
            missile["x"] += missile_speed
            if missile["x"] > screen.get_width():
                missile_to_destroy.append(missile)

        for alien in all_aliens:  # Changes here
            alien_rect = pygame.Rect(alien.x, alien.y, alien.spr_enemy.get_width(), alien.spr_enemy.get_height())
            for missile in all_missiles:
                missile_rect = pygame.Rect(missile["x"], missile["y"], spr_missile.get_width(), spr_missile.get_height())
                if missile_rect.colliderect(alien_rect):
                    aliens_to_remove.add(alien)
                    missile_to_destroy.append(missile)

            # Do something if alien hits player
        for alien in aliens_to_remove:
            alien.x = screen.get_width()
            alien.y = random.randint(0, screen.get_height() - alien.spr_enemy.get_height())
            score +=10
        
        if score > 99:
            alien.speed += 0.2

        for alien in all_aliens:
            alien.move()

        for m in missile_to_destroy:
            all_missiles.remove(m)
        

        utils.show_score (100, 10, score, font, screen)

    pygame.display.update()
