#score
def show_score(x, y, score_value, font, screen):
    score = font.render("score :" + str(score_value), True, (255,255,255))
    screen.blit(score, (x, y))